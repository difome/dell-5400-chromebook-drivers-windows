# Sarien i8042 → Virtual HID keyboard prototype

This is the first hardware-validation driver for the Dell Latitude 5400
Chromebook (Google Sarien) running Windows 10 x64. It polls the firmware/EC
emulated i8042 keyboard ports (`0x60`/`0x64`), decodes the translated PS/2
scan-code set 1 bytes delivered to the host,
and publishes a normal keyboard through Microsoft's Virtual HID Framework.
The HID device also has a Consumer Control collection for Chromebook action
keys.

## What this prototype proves

The critical unknown is whether the RW_LEGACY/edk2 boot path leaves the
emulated i8042 interface alive for Windows. If the `BytesRead` counter stays
at zero while keys are pressed, the next step is firmware/ACPI work—not more
keyboard-class code. If bytes arrive, this driver is a viable base for a
production keyboard driver.

This prototype does not bind to `ACPI\PNP0303`; it uses the root test ID
`Root\SarienI8042Vhf`. The supplied Windows report is not a complete device
inventory. The install script therefore inspects `PNP0303`, `PNP030B`, and
`GOOG000A`, but only refuses to start when a function-driver service is already
attached to one of those nodes or `i8042prt` is running. A firmware node with
no driver owner is reported as a warning and is safe enough for this diagnostic
prototype.

## Build

Requirements:

- Visual Studio 2022 or newer with the Desktop C++ workload
- Visual Studio NuGet support (the project pins the official WDK/SDK NuGet
  packages at `10.0.28000.2526`)
- x64 Debug configuration for initial testing

Open `SarienI8042.sln`, restore NuGet packages, and build `Debug | x64`. The package output must contain
`SarienI8042.sys`, `SarienI8042.inf`, and a generated/test-signed catalog.
Alternatively, run `scripts/build-driver.ps1` after Visual Studio and WDK are
installed. The script creates ready-to-copy ZIP files in `artifacts`; the Debug
ZIP is intended for the first hardware capture.

The driver uses `VhfKm.lib` and requires Windows 10 or newer. Test signing must
be enabled and the produced package must actually be test-signed; merely
enabling test mode does not make an unsigned INF acceptable (the supplied
SetupAPI log shows error `0xE000022F` for exactly that reason).

The INF targets Windows 10 build 16299 or newer. Windows 10 IoT Enterprise
LTSC 2019 (17763) and LTSC 2021 (19044) satisfy that requirement. VHF is an
in-box Windows 10 component, and the driver requests KMDF 1.15, which shipped
with the original Windows 10 release.

## First hardware test

1. Back up important data and attach an external USB keyboard.
2. Use a kernel debugger if possible. A faulty port driver can crash Windows.
3. Run `bcdedit /set testsigning on` as administrator and reboot. On the Sarien
   coreboot/RW_LEGACY setup Secure Boot is normally unavailable, so there is no
   firmware-menu setting to change. The installer only stops if Windows
   explicitly reports Secure Boot as enabled, and imports the matching public
   test certificate automatically.
4. In an elevated PowerShell prompt run `./collect-diagnostics.ps1` and keep
   the generated ZIP.
5. From the unpacked Debug package run:

   `./install-test.ps1`

6. Press keys and inspect messages beginning with `SarienI8042` in WinDbg or
   DbgView with kernel capture enabled.
7. Remove the prototype with `./uninstall-test.ps1`. Add
   `-RemoveTestCertificate` to remove the imported certificate too.

Before installing the prototype, run `collect-diagnostics.ps1` from an
elevated PowerShell prompt. It checks both firmware identities (`GOOG000A` and
`PNP0303`), i8042/VHF services, the FADT 8042 boot flag, allocated resources,
power state, relevant events, and SetupAPI history, then creates a ZIP in the
`diagnostics` directory.

## Current limitations

- Prototype polling is used instead of IRQ 1 because a root-enumerated node has
  no translated ACPI resources. A production driver should bind to corrected
  ACPI resources or use a firmware fix and interrupt-driven input.
- Boot-keyboard 6-key rollover only; Pause is ignored and Print Screen is
  simplified.
- Chromium's translated set-1 PS/2 codes are mapped for Back, Forward, Refresh,
  Fullscreen, Overview, Screenshot, brightness, playback and volume. Debug builds
  print every make/break code with the `SarienI8042: scan` prefix.
- Direct port access is x64-specific and must not be enabled on arbitrary PCs.
- LED output reports (Caps/Num/Scroll Lock back to the EC) are not implemented.

## Two top-row builds

The build script can produce two mutually exclusive packages:

- `ActionKeys`: ChromeOS-style browser, brightness, audio and screenshot keys.
  Snapshot is emitted as a real keyboard Print Screen usage for Windows.
- `FunctionKeys`: the Sarien action positions are translated directly to their
  printed F1-F9/F12 labels; F10/F11 already arrive as ordinary function keys.

Build them with `-TopRowMode ActionKeys` or `-TopRowMode FunctionKeys`. Fn is
handled inside the EC and normally has no host scan code. Therefore the
FunctionKeys package makes those positions function keys unconditionally; it
cannot invert Fn back into action keys without evidence that Fn is host-visible.

## Safety boundary

Install only on the specified Sarien test machine. Do not install while
`i8042prt` is already consuming the same hardware. The test is recoverable by
booting Safe Mode and removing `Root\SarienI8042Vhf`/the service if necessary.

